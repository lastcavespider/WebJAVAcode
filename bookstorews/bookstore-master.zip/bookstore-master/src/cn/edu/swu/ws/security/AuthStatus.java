package cn.edu.swu.ws.security;

public enum AuthStatus {
    LOGIN_SUCCESS,
    LOGIN_FAILED;
}
