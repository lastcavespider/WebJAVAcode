package cn.edu.swu.ws.common;

public class Conf {
    public static int PAGE_SIZE = 4;
}
