package cn.edu.swu.ws.user;

import cn.edu.swu.ws.db.BaseRepo;

public class UserRepo extends BaseRepo {
}
